# ⚽ SportsOracle Bot — AI Football Prediction Engine

A powerful Telegram bot that builds a 10-odds daily accumulator ticket from live football data and provides deep match analysis across all world leagues.

---

## 🚀 Features

- **Daily 10-Odds Ticket** — Auto-selected from best confidence picks worldwide
- **Manual Pick Override** — Add your own picks to blend into the ticket
- **Deep Match Analysis** — Full breakdown: form, H2H, injuries, xG, BTTS, corners
- **On-Demand Analysis** — `/analyze Team A vs Team B` for any upcoming match
- **Auto Daily Delivery** — Subscribe your channel to get the ticket at 7 AM daily
- **All Leagues Worldwide** — Premier League, LaLiga, Serie A, Bundesliga, Ligue 1, Eredivisie, and hundreds more

---

## ⚙️ Setup

### 1. Clone the repo
```bash
git clone https://github.com/marvinricch/sportsOracle.git
cd sportsOracle
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Configure environment variables
```bash
cp .env.example .env
```
Edit `.env`:
```
BOT_TOKEN=your_telegram_bot_token
API_FOOTBALL_KEY=your_api_football_key
```

**Get your API-Football key:** https://dashboard.api-football.com/

### 4. Run locally
```bash
python bot.py
```

---

## 🚂 Deploy to Railway

1. Push to GitHub
2. Connect repo to [Railway](https://railway.app)
3. Add environment variables:
   - `BOT_TOKEN`
   - `API_FOOTBALL_KEY`
4. Railway auto-detects the Procfile and deploys

---

## 📱 Bot Commands

| Command | Description |
|---------|-------------|
| `/start` | Launch bot with main menu |
| `/ticket` | Get today's 10-odds ticket immediately |
| `/analyze Arsenal vs Chelsea` | Deep analysis of any match |
| `/fixtures` | List today's upcoming fixtures |
| `/addpick` | Manually add a pick to today's ticket |
| `/subscribe` | Get daily ticket at 7 AM automatically |
| `/unsubscribe` | Stop daily delivery |

---

## 🔑 API-Football Key

- Free plan: 100 requests/day
- Pro plan: Unlimited + odds data
- Get key at: https://www.api-football.com/

**Check your existing key:** Log into https://dashboard.api-football.com/ — your key is on the dashboard.

---

## 📁 File Structure

```
sportsOracle/
├── bot.py          # Main Telegram bot logic
├── api.py          # API-Football wrapper
├── predictor.py    # AI prediction & analysis engine
├── formatter.py    # Message formatting for Telegram
├── requirements.txt
├── Procfile        # Railway deployment
└── .env.example    # Environment variables template
```

---

## ⚠️ Disclaimer

Predictions are for informational purposes only. Always bet responsibly.
